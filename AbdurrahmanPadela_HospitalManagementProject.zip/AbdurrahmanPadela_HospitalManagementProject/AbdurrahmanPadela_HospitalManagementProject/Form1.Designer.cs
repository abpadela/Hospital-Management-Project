﻿
namespace AbdurrahmanPadela_HospitalManagementProject
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.firstnamelabel = new System.Windows.Forms.Label();
            this.lastnamelabel = new System.Windows.Forms.Label();
            this.genderlabel = new System.Windows.Forms.Label();
            this.agelabel = new System.Windows.Forms.Label();
            this.emaillabel = new System.Windows.Forms.Label();
            this.phonenumberlabel = new System.Windows.Forms.Label();
            this.Homelabel = new System.Windows.Forms.Label();
            this.Stateresidencelabel = new System.Windows.Forms.Label();
            this.Ziplabel = new System.Windows.Forms.Label();
            this.firstnametextBox = new System.Windows.Forms.TextBox();
            this.lastnametextBox = new System.Windows.Forms.TextBox();
            this.agetextBox = new System.Windows.Forms.TextBox();
            this.emailtextBox = new System.Windows.Forms.TextBox();
            this.phonetextBox = new System.Windows.Forms.TextBox();
            this.hometextBox = new System.Windows.Forms.TextBox();
            this.statetextBox = new System.Windows.Forms.TextBox();
            this.ziptextBox = new System.Windows.Forms.TextBox();
            this.genderlistBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.operationtextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.datetextBox = new System.Windows.Forms.TextBox();
            this.roomnumberlabel = new System.Windows.Forms.Label();
            this.addpatientbutton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.totalpatientvisitcostlabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.numbervisitstextBox = new System.Windows.Forms.TextBox();
            this.bloodpressureSlabel = new System.Windows.Forms.Label();
            this.weightlabel = new System.Windows.Forms.Label();
            this.bloodpressureStextBox = new System.Windows.Forms.TextBox();
            this.weighttextBox = new System.Windows.Forms.TextBox();
            this.bloodpressureDlabel = new System.Windows.Forms.Label();
            this.bloodpressureDtextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.stevenradioButton = new System.Windows.Forms.RadioButton();
            this.michaelradioButton = new System.Windows.Forms.RadioButton();
            this.exportbutton = new System.Windows.Forms.Button();
            this.Roomlabel = new System.Windows.Forms.Label();
            this.weightbutton = new System.Windows.Forms.Button();
            this.hellobutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, -4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1436, 358);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // firstnamelabel
            // 
            this.firstnamelabel.AutoSize = true;
            this.firstnamelabel.Location = new System.Drawing.Point(161, 394);
            this.firstnamelabel.Name = "firstnamelabel";
            this.firstnamelabel.Size = new System.Drawing.Size(152, 32);
            this.firstnamelabel.TabIndex = 1;
            this.firstnamelabel.Text = "First Name";
            // 
            // lastnamelabel
            // 
            this.lastnamelabel.AutoSize = true;
            this.lastnamelabel.Location = new System.Drawing.Point(161, 460);
            this.lastnamelabel.Name = "lastnamelabel";
            this.lastnamelabel.Size = new System.Drawing.Size(151, 32);
            this.lastnamelabel.TabIndex = 2;
            this.lastnamelabel.Text = "Last Name";
            this.lastnamelabel.Click += new System.EventHandler(this.lastnamelabel_Click);
            // 
            // genderlabel
            // 
            this.genderlabel.AutoSize = true;
            this.genderlabel.Location = new System.Drawing.Point(174, 529);
            this.genderlabel.Name = "genderlabel";
            this.genderlabel.Size = new System.Drawing.Size(110, 32);
            this.genderlabel.TabIndex = 3;
            this.genderlabel.Text = "Gender";
            // 
            // agelabel
            // 
            this.agelabel.AutoSize = true;
            this.agelabel.Location = new System.Drawing.Point(190, 601);
            this.agelabel.Name = "agelabel";
            this.agelabel.Size = new System.Drawing.Size(66, 32);
            this.agelabel.TabIndex = 4;
            this.agelabel.Text = "Age";
            this.agelabel.Click += new System.EventHandler(this.agelabel_Click);
            // 
            // emaillabel
            // 
            this.emaillabel.AutoSize = true;
            this.emaillabel.Location = new System.Drawing.Point(174, 663);
            this.emaillabel.Name = "emaillabel";
            this.emaillabel.Size = new System.Drawing.Size(87, 32);
            this.emaillabel.TabIndex = 5;
            this.emaillabel.Text = "Email";
            // 
            // phonenumberlabel
            // 
            this.phonenumberlabel.AutoSize = true;
            this.phonenumberlabel.Location = new System.Drawing.Point(132, 728);
            this.phonenumberlabel.Name = "phonenumberlabel";
            this.phonenumberlabel.Size = new System.Drawing.Size(205, 32);
            this.phonenumberlabel.TabIndex = 6;
            this.phonenumberlabel.Text = "Phone Number";
            this.phonenumberlabel.Click += new System.EventHandler(this.phonenumberlabel_Click);
            // 
            // Homelabel
            // 
            this.Homelabel.AutoSize = true;
            this.Homelabel.Location = new System.Drawing.Point(136, 784);
            this.Homelabel.Name = "Homelabel";
            this.Homelabel.Size = new System.Drawing.Size(201, 32);
            this.Homelabel.TabIndex = 7;
            this.Homelabel.Text = "Home Address";
            // 
            // Stateresidencelabel
            // 
            this.Stateresidencelabel.AutoSize = true;
            this.Stateresidencelabel.Location = new System.Drawing.Point(132, 841);
            this.Stateresidencelabel.Name = "Stateresidencelabel";
            this.Stateresidencelabel.Size = new System.Drawing.Size(224, 32);
            this.Stateresidencelabel.TabIndex = 8;
            this.Stateresidencelabel.Text = "State Residence";
            // 
            // Ziplabel
            // 
            this.Ziplabel.AutoSize = true;
            this.Ziplabel.Location = new System.Drawing.Point(160, 909);
            this.Ziplabel.Name = "Ziplabel";
            this.Ziplabel.Size = new System.Drawing.Size(124, 32);
            this.Ziplabel.TabIndex = 9;
            this.Ziplabel.Text = "Zip code";
            // 
            // firstnametextBox
            // 
            this.firstnametextBox.Location = new System.Drawing.Point(386, 391);
            this.firstnametextBox.Name = "firstnametextBox";
            this.firstnametextBox.Size = new System.Drawing.Size(434, 38);
            this.firstnametextBox.TabIndex = 10;
            // 
            // lastnametextBox
            // 
            this.lastnametextBox.Location = new System.Drawing.Point(386, 460);
            this.lastnametextBox.Name = "lastnametextBox";
            this.lastnametextBox.Size = new System.Drawing.Size(434, 38);
            this.lastnametextBox.TabIndex = 11;
            // 
            // agetextBox
            // 
            this.agetextBox.Location = new System.Drawing.Point(386, 601);
            this.agetextBox.Name = "agetextBox";
            this.agetextBox.Size = new System.Drawing.Size(434, 38);
            this.agetextBox.TabIndex = 13;
            this.agetextBox.TextChanged += new System.EventHandler(this.agetextBox_TextChanged);
            // 
            // emailtextBox
            // 
            this.emailtextBox.Location = new System.Drawing.Point(386, 663);
            this.emailtextBox.Name = "emailtextBox";
            this.emailtextBox.Size = new System.Drawing.Size(434, 38);
            this.emailtextBox.TabIndex = 14;
            // 
            // phonetextBox
            // 
            this.phonetextBox.Location = new System.Drawing.Point(386, 725);
            this.phonetextBox.Name = "phonetextBox";
            this.phonetextBox.Size = new System.Drawing.Size(434, 38);
            this.phonetextBox.TabIndex = 15;
            // 
            // hometextBox
            // 
            this.hometextBox.Location = new System.Drawing.Point(386, 784);
            this.hometextBox.Name = "hometextBox";
            this.hometextBox.Size = new System.Drawing.Size(434, 38);
            this.hometextBox.TabIndex = 16;
            // 
            // statetextBox
            // 
            this.statetextBox.Location = new System.Drawing.Point(386, 841);
            this.statetextBox.Name = "statetextBox";
            this.statetextBox.Size = new System.Drawing.Size(434, 38);
            this.statetextBox.TabIndex = 17;
            // 
            // ziptextBox
            // 
            this.ziptextBox.Location = new System.Drawing.Point(386, 906);
            this.ziptextBox.Name = "ziptextBox";
            this.ziptextBox.Size = new System.Drawing.Size(434, 38);
            this.ziptextBox.TabIndex = 18;
            // 
            // genderlistBox
            // 
            this.genderlistBox.FormattingEnabled = true;
            this.genderlistBox.ItemHeight = 31;
            this.genderlistBox.Items.AddRange(new object[] {
            "Male",
            "Female",
            "Other"});
            this.genderlistBox.Location = new System.Drawing.Point(386, 516);
            this.genderlistBox.Name = "genderlistBox";
            this.genderlistBox.Size = new System.Drawing.Size(434, 66);
            this.genderlistBox.TabIndex = 19;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(863, 394);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(211, 32);
            this.label1.TabIndex = 20;
            this.label1.Text = "Name of Doctor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(237, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1171, 78);
            this.label2.TabIndex = 22;
            this.label2.Text = "HOSPITAL MANAGEMENT SYSTEM";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(863, 466);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(242, 32);
            this.label3.TabIndex = 23;
            this.label3.Text = "Type of Operation";
            // 
            // operationtextBox
            // 
            this.operationtextBox.Location = new System.Drawing.Point(1124, 466);
            this.operationtextBox.Name = "operationtextBox";
            this.operationtextBox.Size = new System.Drawing.Size(348, 38);
            this.operationtextBox.TabIndex = 24;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(894, 535);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 32);
            this.label4.TabIndex = 25;
            this.label4.Text = "Date";
            // 
            // datetextBox
            // 
            this.datetextBox.Location = new System.Drawing.Point(1067, 535);
            this.datetextBox.Name = "datetextBox";
            this.datetextBox.Size = new System.Drawing.Size(405, 38);
            this.datetextBox.TabIndex = 26;
            // 
            // roomnumberlabel
            // 
            this.roomnumberlabel.AutoSize = true;
            this.roomnumberlabel.Location = new System.Drawing.Point(1263, 601);
            this.roomnumberlabel.Name = "roomnumberlabel";
            this.roomnumberlabel.Size = new System.Drawing.Size(197, 32);
            this.roomnumberlabel.TabIndex = 27;
            this.roomnumberlabel.Text = "Room Number";
            // 
            // addpatientbutton
            // 
            this.addpatientbutton.Location = new System.Drawing.Point(1370, 853);
            this.addpatientbutton.Name = "addpatientbutton";
            this.addpatientbutton.Size = new System.Drawing.Size(260, 73);
            this.addpatientbutton.TabIndex = 29;
            this.addpatientbutton.Text = "ADD PATIENT";
            this.addpatientbutton.UseVisualStyleBackColor = true;
            this.addpatientbutton.Click += new System.EventHandler(this.addpatientbutton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(1370, 949);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(258, 82);
            this.exitButton.TabIndex = 30;
            this.exitButton.Text = "EXIT";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // totalpatientvisitcostlabel
            // 
            this.totalpatientvisitcostlabel.AutoSize = true;
            this.totalpatientvisitcostlabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalpatientvisitcostlabel.Location = new System.Drawing.Point(1178, 728);
            this.totalpatientvisitcostlabel.Name = "totalpatientvisitcostlabel";
            this.totalpatientvisitcostlabel.Size = new System.Drawing.Size(425, 46);
            this.totalpatientvisitcostlabel.TabIndex = 31;
            this.totalpatientvisitcostlabel.Text = "Total Patient Visit Cost";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(877, 654);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(222, 32);
            this.label7.TabIndex = 32;
            this.label7.Text = "Number of Visits";
            // 
            // numbervisitstextBox
            // 
            this.numbervisitstextBox.Location = new System.Drawing.Point(1134, 651);
            this.numbervisitstextBox.Name = "numbervisitstextBox";
            this.numbervisitstextBox.Size = new System.Drawing.Size(336, 38);
            this.numbervisitstextBox.TabIndex = 33;
            // 
            // bloodpressureSlabel
            // 
            this.bloodpressureSlabel.AutoSize = true;
            this.bloodpressureSlabel.Location = new System.Drawing.Point(865, 810);
            this.bloodpressureSlabel.Name = "bloodpressureSlabel";
            this.bloodpressureSlabel.Size = new System.Drawing.Size(315, 32);
            this.bloodpressureSlabel.TabIndex = 34;
            this.bloodpressureSlabel.Text = "Blood Pressure Systolic";
            // 
            // weightlabel
            // 
            this.weightlabel.AutoSize = true;
            this.weightlabel.Location = new System.Drawing.Point(877, 915);
            this.weightlabel.Name = "weightlabel";
            this.weightlabel.Size = new System.Drawing.Size(104, 32);
            this.weightlabel.TabIndex = 35;
            this.weightlabel.Text = "Weight";
            // 
            // bloodpressureStextBox
            // 
            this.bloodpressureStextBox.Location = new System.Drawing.Point(1186, 804);
            this.bloodpressureStextBox.Name = "bloodpressureStextBox";
            this.bloodpressureStextBox.Size = new System.Drawing.Size(169, 38);
            this.bloodpressureStextBox.TabIndex = 36;
            // 
            // weighttextBox
            // 
            this.weighttextBox.Location = new System.Drawing.Point(1020, 909);
            this.weighttextBox.Name = "weighttextBox";
            this.weighttextBox.Size = new System.Drawing.Size(263, 38);
            this.weighttextBox.TabIndex = 37;
            // 
            // bloodpressureDlabel
            // 
            this.bloodpressureDlabel.AutoSize = true;
            this.bloodpressureDlabel.Location = new System.Drawing.Point(865, 853);
            this.bloodpressureDlabel.Name = "bloodpressureDlabel";
            this.bloodpressureDlabel.Size = new System.Drawing.Size(325, 32);
            this.bloodpressureDlabel.TabIndex = 38;
            this.bloodpressureDlabel.Text = "Blood Pressure Diastolic";
            // 
            // bloodpressureDtextBox
            // 
            this.bloodpressureDtextBox.Location = new System.Drawing.Point(1196, 850);
            this.bloodpressureDtextBox.Name = "bloodpressureDtextBox";
            this.bloodpressureDtextBox.Size = new System.Drawing.Size(159, 38);
            this.bloodpressureDtextBox.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(854, 731);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(294, 32);
            this.label6.TabIndex = 40;
            this.label6.Text = "Total Patient Cost in $";
            // 
            // stevenradioButton
            // 
            this.stevenradioButton.AutoSize = true;
            this.stevenradioButton.Location = new System.Drawing.Point(1170, 375);
            this.stevenradioButton.Name = "stevenradioButton";
            this.stevenradioButton.Size = new System.Drawing.Size(178, 36);
            this.stevenradioButton.TabIndex = 41;
            this.stevenradioButton.TabStop = true;
            this.stevenradioButton.Text = "Dr.Steven";
            this.stevenradioButton.UseVisualStyleBackColor = true;
            this.stevenradioButton.CheckedChanged += new System.EventHandler(this.stevenradioButton_CheckedChanged);
            // 
            // michaelradioButton
            // 
            this.michaelradioButton.AutoSize = true;
            this.michaelradioButton.Location = new System.Drawing.Point(1170, 417);
            this.michaelradioButton.Name = "michaelradioButton";
            this.michaelradioButton.Size = new System.Drawing.Size(188, 36);
            this.michaelradioButton.TabIndex = 42;
            this.michaelradioButton.TabStop = true;
            this.michaelradioButton.Text = "Dr.Michael";
            this.michaelradioButton.UseVisualStyleBackColor = true;
            this.michaelradioButton.CheckedChanged += new System.EventHandler(this.michaelradioButton_CheckedChanged);
            // 
            // exportbutton
            // 
            this.exportbutton.Location = new System.Drawing.Point(1147, 965);
            this.exportbutton.Name = "exportbutton";
            this.exportbutton.Size = new System.Drawing.Size(168, 66);
            this.exportbutton.TabIndex = 43;
            this.exportbutton.Text = "EXPORT";
            this.exportbutton.UseVisualStyleBackColor = true;
            this.exportbutton.Click += new System.EventHandler(this.exportbutton_Click);
            // 
            // Roomlabel
            // 
            this.Roomlabel.AutoSize = true;
            this.Roomlabel.Location = new System.Drawing.Point(913, 604);
            this.Roomlabel.Name = "Roomlabel";
            this.Roomlabel.Size = new System.Drawing.Size(90, 32);
            this.Roomlabel.TabIndex = 44;
            this.Roomlabel.Text = "Room";
            // 
            // weightbutton
            // 
            this.weightbutton.Location = new System.Drawing.Point(1386, 777);
            this.weightbutton.Name = "weightbutton";
            this.weightbutton.Size = new System.Drawing.Size(225, 52);
            this.weightbutton.TabIndex = 45;
            this.weightbutton.Text = "Weight";
            this.weightbutton.UseVisualStyleBackColor = true;
            this.weightbutton.Click += new System.EventHandler(this.distolebutton_Click);
            // 
            // hellobutton
            // 
            this.hellobutton.Location = new System.Drawing.Point(656, 288);
            this.hellobutton.Name = "hellobutton";
            this.hellobutton.Size = new System.Drawing.Size(177, 56);
            this.hellobutton.TabIndex = 46;
            this.hellobutton.Text = "Hello";
            this.hellobutton.UseVisualStyleBackColor = true;
            this.hellobutton.Click += new System.EventHandler(this.hellobutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1642, 1158);
            this.Controls.Add(this.hellobutton);
            this.Controls.Add(this.weightbutton);
            this.Controls.Add(this.Roomlabel);
            this.Controls.Add(this.exportbutton);
            this.Controls.Add(this.michaelradioButton);
            this.Controls.Add(this.stevenradioButton);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.bloodpressureDtextBox);
            this.Controls.Add(this.bloodpressureDlabel);
            this.Controls.Add(this.weighttextBox);
            this.Controls.Add(this.bloodpressureStextBox);
            this.Controls.Add(this.weightlabel);
            this.Controls.Add(this.bloodpressureSlabel);
            this.Controls.Add(this.numbervisitstextBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.totalpatientvisitcostlabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.addpatientbutton);
            this.Controls.Add(this.roomnumberlabel);
            this.Controls.Add(this.datetextBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.operationtextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.genderlistBox);
            this.Controls.Add(this.ziptextBox);
            this.Controls.Add(this.statetextBox);
            this.Controls.Add(this.hometextBox);
            this.Controls.Add(this.phonetextBox);
            this.Controls.Add(this.emailtextBox);
            this.Controls.Add(this.agetextBox);
            this.Controls.Add(this.lastnametextBox);
            this.Controls.Add(this.firstnametextBox);
            this.Controls.Add(this.Ziplabel);
            this.Controls.Add(this.Stateresidencelabel);
            this.Controls.Add(this.Homelabel);
            this.Controls.Add(this.phonenumberlabel);
            this.Controls.Add(this.emaillabel);
            this.Controls.Add(this.agelabel);
            this.Controls.Add(this.genderlabel);
            this.Controls.Add(this.lastnamelabel);
            this.Controls.Add(this.firstnamelabel);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "HOSPITAL MANAGEMENT SYSTEM";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label firstnamelabel;
        private System.Windows.Forms.Label lastnamelabel;
        private System.Windows.Forms.Label genderlabel;
        private System.Windows.Forms.Label agelabel;
        private System.Windows.Forms.Label emaillabel;
        private System.Windows.Forms.Label phonenumberlabel;
        private System.Windows.Forms.Label Homelabel;
        private System.Windows.Forms.Label Stateresidencelabel;
        private System.Windows.Forms.Label Ziplabel;
        private System.Windows.Forms.TextBox firstnametextBox;
        private System.Windows.Forms.TextBox lastnametextBox;
        private System.Windows.Forms.TextBox agetextBox;
        private System.Windows.Forms.TextBox emailtextBox;
        private System.Windows.Forms.TextBox phonetextBox;
        private System.Windows.Forms.TextBox hometextBox;
        private System.Windows.Forms.TextBox statetextBox;
        private System.Windows.Forms.TextBox ziptextBox;
        private System.Windows.Forms.ListBox genderlistBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox operationtextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox datetextBox;
        private System.Windows.Forms.Label roomnumberlabel;
        private System.Windows.Forms.Button addpatientbutton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label totalpatientvisitcostlabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox numbervisitstextBox;
        private System.Windows.Forms.Label bloodpressureSlabel;
        private System.Windows.Forms.Label weightlabel;
        private System.Windows.Forms.TextBox bloodpressureStextBox;
        private System.Windows.Forms.TextBox weighttextBox;
        private System.Windows.Forms.Label bloodpressureDlabel;
        private System.Windows.Forms.TextBox bloodpressureDtextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RadioButton stevenradioButton;
        private System.Windows.Forms.RadioButton michaelradioButton;
        private System.Windows.Forms.Button exportbutton;
        private System.Windows.Forms.Label Roomlabel;
        private System.Windows.Forms.Button weightbutton;
        private System.Windows.Forms.Button hellobutton;
    }
}

